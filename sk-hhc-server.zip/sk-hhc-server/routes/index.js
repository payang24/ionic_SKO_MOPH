var express = require('express');
var router = express.Router();
var moment = require('moment');

var Service = require('../models/service');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.send({ ok: true, msg: 'Welcome' });
});

router.post('/services', function (req, res, next) {
  let date_serv = req.body.date_serv; // $_POST['vstdate']
  Service.getService(req.hdcPool, date_serv)//เรียกใช้ model และ function ที่ต้องการใน โฟเด้อ models อันนี้เรียกใช้ ไฟล์ service function getService
    .then((rows) => {
      let services = [];
      rows.forEach(v => {//วน loop
        let obj = {};
        obj.hn = v.hn;
        obj.vn = v.vn;
        obj.date_serv = `
                       ${moment(v.date_serv).locale('th').format('D')} 
                       ${moment(v.date_serv).format('MMMM')} 
                       ${moment(v.date_serv).get('year') + 543}`;
        obj.hospcode = v.hospcode;
        obj.ptname = v.fullname;
        obj.sex = v.sex;
        obj.cid = v.cid;
        obj.hosname = v.hosname;
        services.push(obj);
      });
      res.send({ ok: true, rows: services });
      //console.log(rows);
    }, (err) => {
      res.send({ ok: false, error: err });
    });
});
//รับค่าจาก app provider/service
router.post('/detail', function (req, res, next) {
  let cid = req.body.cid; //ส่งค่า cid
  let date_serv = req.body.date_serv;//ส่งค่าวันที่
  Service.getDetail(req.hdcPool,date_serv,cid) //ส่งค่าเข้า model/service ของ server
    .then((rows) => {//ชุดรับจาก query
      let detail = [];
      rows.forEach(v => {//วน loop
        let obj = {};
        obj.date_serv = `
                       ${moment(v.date_serv).locale('th').format('D')} 
                       ${moment(v.date_serv).format('MMMM')} 
                       ${moment(v.date_serv).get('year') + 543}`;
        obj.ptname = v.fullname;
        obj.cid = v.cid;
        obj.sex = v.sex;
        obj.weight = v.weight;
        obj.height = v.height;
        obj.waist_cm = v.waist_cm;
        obj.sbp_1 = v.sbp_1;
        obj.dbp_1 = v.dbp_1;
        obj.bslevel = v.bslevel;
        obj.hospcode = v.hospcode;
        detail.push(obj);
      });
      res.send({ ok: true, rows: detail });
      //console.log(detail);
    }, (err) => {
      res.send({ ok: false, error: err });
    });
});

router.post('/comlist', function (req, res, next) {
  Service.getCommunityServiceList(req.hdcPool)
    .then((rows) => {
      res.send({ ok: true, rows: rows });
    }, (err) => {
      res.send({ ok: false, error: err });
    });
});

router.post('/doctorlist', function (req, res, next) {
  Service.getDoctorList(req.hdcPool)
    .then((rows) => {
      res.send({ ok: true, rows: rows });
    }, (err) => {
      res.send({ ok: false, error: err });
    });
});

router.post('/personal', function (req, res, next) {
  let date_serv = req.body.date_serv; // $_POST['date_serv']
  let cid = req.body.cid;// $_POST['cid']
  Service.getPersonal(req.hdcPool, date_serv,cid)//เรียกใช้ model และ function ที่ต้องการใน โฟเด้อ models อันนี้เรียกใช้ ไฟล์ service function getService
    .then((rows) => {
      let personal = [];
      rows.forEach(v => {//วน loop
        let obj = {};
        obj.pid = v.pid;
        obj.seq = v.seq;
        obj.date_serv = `
                       ${moment(v.date_serv).locale('th').format('D')} 
                       ${moment(v.date_serv).format('MMMM')} 
                       ${moment(v.date_serv).get('year') + 543}`;
        obj.fullname = v.fullname;
        obj.cid = v.cid;
        obj.sex = v.sex;
        obj.birth = `
                       ${moment(v.birth).locale('th').format('D')} 
                       ${moment(v.birth).format('MMMM')} 
                       ${moment(v.birth).get('year') + 543}`;
        obj.instype_new = v.instype_new;
        obj.insid = v.insid;
        obj.main = v.main;
        obj.sub = v.sub;
        obj.house = v.house;
        obj.village = v.village;
        obj.villagename = v.villagename;
        obj.tambonname = v.tambonname;
        obj.ampurname = v.ampurname;
        obj.changwatname = v.changwatname;
        obj.telephone = v.telephone;
        obj.latitude = v.latitude;
        obj.longitude = v.longitude;
        obj.hospcode = v.hospcode;
        obj.hosname = v.hosname;
        personal.push(obj);
      });
      res.send({ ok: true, rows: personal });
      //console.log(rows);
    }, (err) => {
      res.send({ ok: false, error: err });
    });
});

module.exports = router;
