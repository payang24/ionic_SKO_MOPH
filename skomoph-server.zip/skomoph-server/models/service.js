let Q = require('q');

module.exports = {
  getService(db, date_serv) {
    let q = Q.defer();
    //query
    let sql = `
    select 
    n.PID,
    person.HN as hn,
    n.SEQ ,
    n.DATE_SERV as date_serv,
    concat(cprename.prename,person.NAME ," ", person.LNAME) as fullname,
    person.cid, 
    person.sex ,
    n.HOSPCODE as hospcode,
    chospital.hosname
    from ncdscreen as n
    inner join person on person.HOSPCODE=n.HOSPCODE AND person.PID = n.PID
    inner join cprename ON person.PRENAME = cprename.id_prename
    inner join  chospital ON n.HOSPCODE = chospital.hoscode
    where n.DATE_SERV= ?

    `;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [date_serv], (err, rows) => {
          if (err) q.reject(err);
          else q.resolve(rows);
        });
        conn.release();
      }
    });

    return q.promise;
  },
  
  getCommunityServiceList(db) {
    let q = Q.defer();

    let sql = `
select ovst_community_service_type_code as code, ovst_community_service_type_name as name,
ovst_community_service_type_id as id
from ovst_community_service_type
where (ovst_community_service_type_code like '1A%') or (ovst_community_service_type_code like '1D%')
order by ovst_community_service_type_name`;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [], (err, rows) => {
          if (err) q.reject(err);
          else q.resolve(rows);
        });
        conn.release();
      }
    });

    return q.promise;
  },

  getDoctorList(db) {
    let q = Q.defer();

    let sql = `select code, name from doctor order by name`;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [], (err, rows) => {
          if (err) q.reject(err);
          else q.resolve(rows);
        });
        conn.release();
      }
    });

    return q.promise;
  },

  saveImage(db, cid, images) {
    let q = Q.defer();

    let sql = `insert into images(cid, images) values(?, ?)`;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [cid, images], (err) => {
          if (err) q.reject(err);
          else q.resolve();
        });
        conn.release();
      }
    });

    return q.promise;
  },

  updateImage(db, cid, images) {
    let q = Q.defer();

    let sql = `update images set images=? where cid=?`;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [images, cid], (err) => {
          if (err) q.reject(err);
          else q.resolve();
        });
        conn.release();
      }
    });

    return q.promise;
  },

  checkImage(db, cid) {
    let q = Q.defer();

    let sql = `select count(*) as total from images where cid=?`;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [cid], (err, rows) => {
          if (err) q.reject(err);
          else {
            q.resolve(rows[0].total);
          }
        });
        conn.release();
      }
    });

    return q.promise;
  },

  getImage(db, cid) {
    let q = Q.defer();

    let sql = `select image from images where cid=?`;

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(sql, [cid], (err, rows) => {
          if (err) q.reject(err);
          else {
            let image = rows.length ? rows[0].image : null;
            q.resolve(image);
          }
        });
        conn.release();
      }
    });

    return q.promise;
  },

  removeImage(db, cid) {
    let q = Q.defer();

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        conn.query(process.env.SQL_DELETE_IMAGE, [cid], (err, rows) => {
          if (err) q.reject(err);
          else {
            q.resolve();
          }
        });
        conn.release();
      }
    });

    return q.promise;
  },

  login(db, username, password,cid,hospcode) {
    let q = Q.defer();

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        let sql = `SELECT * FROM users WHERE username=? AND password=?`;
        conn.query(sql, [username, password,cid,hospcode], (err, rows) => {
          if (err) q.reject(err);
          else {
            q.resolve(rows);
          }
        });
        conn.release();
      }
    });

    return q.promise;
  },

  saveDeviceToken(db, username, deviceToken) {
    let q = Q.defer();

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        let sql = `device_token(username, device_token) VALUE(?, ?)`;
        conn.query(sql, [username, deviceToken], (err, rows) => {
          if (err) q.reject(err);
          else {
            q.resolve(rows);
          }
        });
        conn.release();
      }
    });

    return q.promise;
  },

  getDeviceToken(db, username) {
    let q = Q.defer();

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        let sql = `SELECT device_token FROM device_token WHERE username=?`;
        conn.query(sql, [username], (err, rows) => {
          if (err) q.reject(err);
          else {
            q.resolve(rows);
          }
        });
        conn.release();
      }
    });

    return q.promise;
  },

  getUsers(db) {
    let q = Q.defer();

    db.getConnection((err, conn) => {
      if (err) {
        q.reject(err);
      } else {
        let sql = `SELECT username FROM device_token group by username`;
        conn.query(sql, [], (err, rows) => {
          if (err) q.reject(err);
          else {
            q.resolve(rows);
          }
        });
        conn.release();
      }
    });

    return q.promise;
  }
}