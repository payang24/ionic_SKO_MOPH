import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
/*
  Generated class for the Emr provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
export var Emr = (function () {
    function Emr(http) {
        this.http = http;
        console.log('Hello Emr Provider');
    }
    Emr.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    Emr.ctorParameters = [
        { type: Http, },
    ];
    return Emr;
}());
//# sourceMappingURL=emr.js.map