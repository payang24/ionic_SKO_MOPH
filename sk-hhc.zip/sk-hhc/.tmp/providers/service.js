import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
export var Service = (function () {
    function Service(http, url) {
        this.http = http;
        this.url = url;
        console.log('Hello Service Provider');
    }
    Service.prototype.getServices = function (vstdate) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var headers = new Headers({ 'Content-Type': 'application/json' });
            var options = new RequestOptions({ headers: headers });
            var body = { vstdate: vstdate };
            _this.http.post(_this.url + "/services", body, options)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                resolve(data);
            }, function (err) {
                reject(err);
            });
        });
    };
    Service.prototype.getComList = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var headers = new Headers({ 'Content-Type': 'application/json' });
            var options = new RequestOptions({ headers: headers });
            // let body = { vstdate: vstdate };
            _this.http.post(_this.url + "/comlist", options)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                resolve(data);
            }, function (err) {
                reject(err);
            });
        });
    };
    Service.prototype.getDoctorList = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var headers = new Headers({ 'Content-Type': 'application/json' });
            var options = new RequestOptions({ headers: headers });
            // let body = { vstdate: vstdate };
            _this.http.post(_this.url + "/doctorlist", options)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                resolve(data);
            }, function (err) {
                reject(err);
            });
        });
    };
    Service.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    Service.ctorParameters = [
        { type: Http, },
        { type: undefined, decorators: [{ type: Inject, args: ['API_URL',] },] },
    ];
    return Service;
}());
//# sourceMappingURL=service.js.map