import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
/*
  Generated class for the Emr page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
export var EmrPage = (function () {
    function EmrPage(navCtrl) {
        this.navCtrl = navCtrl;
    }
    EmrPage.prototype.ionViewDidLoad = function () {
        console.log('Hello EmrPage Page');
    };
    EmrPage.decorators = [
        { type: Component, args: [{
                    selector: 'page-emr',
                    templateUrl: 'emr.html'
                },] },
    ];
    /** @nocollapse */
    EmrPage.ctorParameters = [
        { type: NavController, },
    ];
    return EmrPage;
}());
//# sourceMappingURL=emr.js.map