import { Component } from '@angular/core';
import { NavController, Platform, ActionSheetController, LoadingController } from 'ionic-angular';
import { EntryPage } from '../entry/entry';
import { EmrDetailPage } from '../emr-detail/emr-detail';
import { Service } from '../../providers/service';
import * as moment from 'moment';
export var HomePage = (function () {
    function HomePage(navCtrl, actionSheetCtrl, platform, serviceProvider, loadingCtrl) {
        this.navCtrl = navCtrl;
        this.actionSheetCtrl = actionSheetCtrl;
        this.platform = platform;
        this.serviceProvider = serviceProvider;
        this.loadingCtrl = loadingCtrl;
        this.vstdate = moment().format('YYYY-MM-DD');
    }
    HomePage.prototype.getServices = function () {
        var _this = this;
        var loading = this.loadingCtrl.create({
            content: 'Please wait...'
        });
        loading.present();
        this.serviceProvider.getServices(this.vstdate)
            .then(function (data) {
            if (data.ok) {
                _this.services = data.rows;
            }
            loading.dismiss();
        }, function (err) {
            loading.dismiss();
            console.error(err);
        });
    };
    HomePage.prototype.ionViewWillEnter = function () {
        this.getServices();
    };
    HomePage.prototype.showMenu = function () {
        var _this = this;
        var actionSheet = this.actionSheetCtrl.create({
            title: 'Modify your album',
            buttons: [
                {
                    text: 'บันทึกข้อมูล',
                    icon: !this.platform.is('ios') ? 'create' : null,
                    handler: function () {
                        _this.navCtrl.push(EntryPage, { hn: null, vn: null });
                    }
                },
                {
                    text: 'ข้อมูลบริการ',
                    icon: !this.platform.is('ios') ? 'search' : null,
                    handler: function () {
                        _this.navCtrl.push(EmrDetailPage, { hn: null });
                    }
                },
                {
                    text: 'ยกเลิก',
                    icon: !this.platform.is('ios') ? 'close' : null,
                    role: 'cancel',
                    handler: function () {
                        console.log('Cancel clicked');
                    }
                }
            ]
        });
        actionSheet.present();
    };
    HomePage.prototype.search = function (event) {
        var val = event.target.value;
        console.log(val);
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [
        { type: NavController, },
        { type: ActionSheetController, },
        { type: Platform, },
        { type: Service, },
        { type: LoadingController, },
    ];
    return HomePage;
}());
//# sourceMappingURL=home.js.map