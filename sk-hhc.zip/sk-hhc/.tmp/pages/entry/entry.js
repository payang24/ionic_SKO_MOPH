import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Service } from '../../providers/service';
export var EntryPage = (function () {
    function EntryPage(navCtrl, serviceProvider) {
        this.navCtrl = navCtrl;
        this.serviceProvider = serviceProvider;
    }
    EntryPage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.serviceProvider.getComList()
            .then(function (data) {
            if (data.ok) {
                _this.comlists = data.rows;
            }
        }, function (err) { });
        this.serviceProvider.getDoctorList()
            .then(function (data) {
            if (data.ok) {
                _this.doctorlists = data.rows;
            }
        }, function (err) { });
    };
    EntryPage.prototype.save = function () {
    };
    EntryPage.prototype.remove = function () {
    };
    EntryPage.decorators = [
        { type: Component, args: [{
                    selector: 'page-entry',
                    templateUrl: 'entry.html'
                },] },
    ];
    /** @nocollapse */
    EntryPage.ctorParameters = [
        { type: NavController, },
        { type: Service, },
    ];
    return EntryPage;
}());
//# sourceMappingURL=entry.js.map