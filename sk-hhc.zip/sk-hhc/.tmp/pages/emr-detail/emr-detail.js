import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
/*
  Generated class for the EmrDetail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
export var EmrDetailPage = (function () {
    function EmrDetailPage(navCtrl) {
        this.navCtrl = navCtrl;
    }
    EmrDetailPage.prototype.ionViewDidLoad = function () {
        console.log('Hello EmrDetailPage Page');
    };
    EmrDetailPage.decorators = [
        { type: Component, args: [{
                    selector: 'page-emr-detail',
                    templateUrl: 'emr-detail.html'
                },] },
    ];
    /** @nocollapse */
    EmrDetailPage.ctorParameters = [
        { type: NavController, },
    ];
    return EmrDetailPage;
}());
//# sourceMappingURL=emr-detail.js.map