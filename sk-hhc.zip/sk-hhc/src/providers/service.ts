import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class Service {

  constructor(public http: Http, @Inject('API_URL') private url: string) {
    console.log('Hello Service Provider');
  }

  getServices(date_serv: string) {
    return new Promise((resolve, reject) => {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = { date_serv: date_serv };

      this.http.post(`${this.url}/services`, body, options)
        // this.http.get(this.url + '/users')
        .map(res => res.json())
        .subscribe(data => {
          resolve(data)
        }, err => {
          reject(err)
        });
    });
  }

  getDetail(date_serv: string, cid: string) {//รับค่าจากเงื่อนไข .ts
    return new Promise((resolve, reject) => {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = { date_serv: date_serv, cid: cid };//ตัวแปรที่ส่งไป server
      this.http.post(`${this.url}/detail`, body, options)//คำสั่งส่งไป server ไฟล์ index router ค่าที่ต้องรับ
        // this.http.get(this.url + '/users')
        .map(res => res.json())
        .subscribe(data => {
          resolve(data)
        }, err => {
          reject(err)
        });
    });
  }

  getPersonal(date_serv: string, cid: string) {//รับค่าจากเงื่อนไข .ts
    return new Promise((resolve, reject) => {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = { date_serv: date_serv, cid: cid };//ตัวแปรที่ส่งไป server
      this.http.post(`${this.url}/personal`, body, options)//คำสั่งส่งไป server ไฟล์ index router ค่าที่ต้องรับ
        // this.http.get(this.url + '/users')
        .map(res => res.json())
        .subscribe(data => {
          resolve(data)
        }, err => {
          reject(err)
        });
    });
  }



  getComList() {
    return new Promise((resolve, reject) => {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      // let body = { vstdate: vstdate };

      this.http.post(`${this.url}/comlist`, options)
        // this.http.get(this.url + '/users')
        .map(res => res.json())
        .subscribe(data => {
          resolve(data)
        }, err => {
          reject(err)
        });
    });
  }

  getDoctorList() {
    return new Promise((resolve, reject) => {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      // let body = { vstdate: vstdate };

      this.http.post(`${this.url}/doctorlist`, options)
        // this.http.get(this.url + '/users')
        .map(res => res.json())
        .subscribe(data => {
          resolve(data)
        }, err => {
          reject(err)
        });
    });
  }

  login(username: string, password: string) {
    return new Promise((resolve, reject) => {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let body = { username: username, password: password };

      this.http.post(`${this.url}/users/login`, body, options)
        .map(res => res.json())
        .subscribe(data => {
          resolve(data)
        }, err => {
          reject(err)
        });
    });
  }
}
