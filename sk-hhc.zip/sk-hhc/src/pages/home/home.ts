import { Component } from '@angular/core';

import { NavController, Platform, ActionSheetController, LoadingController } from 'ionic-angular';
import { EntryPage } from '../entry/entry';
import { EmrDetailPage } from '../emr-detail/emr-detail';
import {ContactPage} from '../contact/contact';

import { IHttpResult, IService } from '../../models';
import { Service } from '../../providers/service';

import * as moment from 'moment';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  services: Array<IService>;
  date_serv: any;
  cid: string;

  constructor(
    public navCtrl: NavController,
    private actionSheetCtrl: ActionSheetController,
    public platform: Platform,
    private serviceProvider: Service,//ประกาศเรียกใช้ function ในไฟล์ชื่อ providers/service
    private loadingCtrl: LoadingController
  ) {
    this.date_serv = moment().format('YYYY-MM-DD');
  }

  getServices() {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });

    loading.present();
    
    this.serviceProvider.getServices(this.date_serv)//เรียกใช้ function
      .then((data: IHttpResult) => {
        if (data.ok) {
          this.services = data.rows;
        }
        loading.dismiss();
      }, (err) => { 
        loading.dismiss();
        console.error(err);
      });
  }

  ionViewWillEnter() {
    this.getServices();
  }
  showMenu(Service: IService) {
   let actionSheet = this.actionSheetCtrl.create({
     title: 'menu',
     buttons: [
      //  {
      //    text: 'บันทึกข้อมูล',
      //    icon: !this.platform.is('ios') ? 'create' : null,
      //    handler: () => {
      //      this.navCtrl.push(EntryPage, { hn: null, vn: null });
      //    }
      //  },
       {
         text: 'ข้อมูลบริการ ',
         icon: !this.platform.is('ios') ? 'search' : null,
         handler: () => { 
           this.navCtrl.push(EmrDetailPage, { date_serv: this.date_serv, cid: Service.cid   });//ส่งค่าไปหน้าที่ต้องการ (EmrDetailPage)
         }
       },
       {
         text: 'ข้อมูลส่วนตัว ',
         icon: !this.platform.is('ios') ? 'contact' : null,
         handler: () => { 
           this.navCtrl.push(ContactPage, {date_serv: this.date_serv,  cid: Service.cid   });//ส่งค่าไปหน้าที่ต้องการ (ContactPage)
         }
       },
       {
         text: 'ยกเลิก',
         icon: !this.platform.is('ios') ? 'close' : null,
         role: 'cancel',
         handler: () => {
           console.log('Cancel clicked');
         }
       }
     ]
   });

   actionSheet.present();
 }

  search(event) {
    let val = event.target.value;
    console.log(val);
  }  

}
