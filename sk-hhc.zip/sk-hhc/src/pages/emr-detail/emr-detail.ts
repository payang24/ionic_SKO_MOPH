import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { Service } from '../../providers/service';

import { IHttpResult, IService } from '../../models';

@Component({
  selector: 'page-emr-detail',
  templateUrl: 'emr-detail.html'
})
export class EmrDetailPage {
  com_services: Array<string>;
  comlists: Array<any>;
  detail: Array<IService>;
  date_serv: string;
  cid: string;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private serviceProvider: Service,

    private loadingCtrl: LoadingController

  ) {
    this.date_serv = this.navParams.get('date_serv');//รับค่าจากหน้าที่ส่งมา navParams
    this.cid = this.navParams.get('cid');
  }

/*
  getServices() {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });

    loading.present();

    this.serviceProvider.getDetail(this.vstdate, this.cid)
      .then((data: IHttpResult) => {
        
        if (data.ok) {
          this.detail = data.rows;
          console.log(this.detail);
        }
        loading.dismiss();
      }, (err) => {
        loading.dismiss();
        console.error(err);
      });


  }
*/
  ionViewWillEnter() {

     let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });

    console.log('date_serv:='+this.date_serv);
    console.log('cid:='+this.cid);

    loading.present();

    this.serviceProvider.getDetail(this.date_serv, this.cid) //ส่งค่าเงื่อนไขไป providers/service
      .then((data: IHttpResult) => {
        
        if (data.ok) {
          this.detail = data.rows;
        }
        loading.dismiss();
      }, (err) => {
        loading.dismiss();
        console.error(err);
      });

    this.serviceProvider.getComList()
      .then((data: IHttpResult) => {
        if (data.ok) {
          this.comlists = data.rows;
        }
      }, (err) => { });

  }

}
